# TR
## TEORIA REGULACJI
Wykład prowadzony przez Dr. Mzyka. 
Testownik zawiera sporo pytań dotyczących starego kursu "Podstawy Automatyki". Pytania te na dysku AiR są nazywane pytaniami do Greblickiego. W roku 2019 żadne z tych pytań nie pojawiło się na kolokwium. 
Po pytania, które są mocno aktualne należy się kierować do pliku oznaczonego jako wersja 2019 znajdującego się w sąsiadującym folderze na dysku "opracowania pytań kolokwium".
### Co do samego testownika
Jak już zostało wspomniane - testownik nie jest w najlepszej kondycji i nie można mu ufać w 100%. Apeluje do osób uczących się o skrupulatne sprawdzanie poprawności pytań i o ewentualne update'y.
